package id.project.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "DataModel")
public class DataModel {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "nama")
    private String nama;
    @ColumnInfo(name = "tempat_lahir")
    private String tempat_lahir;
    @ColumnInfo(name = "tanggal_lahir")
    private String tanggal_lahir;
    @ColumnInfo(name = "nama_ibu")
    private String nama_ibu;
//    @PrimaryKey
//    @NonNull
//    private String key;

    public DataModel(String nama, String tempat_lahir, String tanggal_lahir, String nama_ibu) {
    }

    public DataModel() {

    }

    public static void remove(int position) {
    }


    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTempat_lahir() {
        return tempat_lahir;
    }

    public void setTempat_lahir(String tempat_lahir) {
        this.tempat_lahir = tempat_lahir;
    }

    public String getTanggal_lahir() {
        return tanggal_lahir;
    }

    public void setTanggal_lahir(String tanggal_lahir) {
        this.tanggal_lahir = tanggal_lahir;
    }

    public String getNama_ibu() {
        return nama_ibu;
    }

    public void setNama_ibu(String nama_ibu) {
        this.nama_ibu = nama_ibu;
    }

//    public String getKey() {
//        return key;
//    }
//    public void setKey (String key){
//        this.key=key;
//    }
}

