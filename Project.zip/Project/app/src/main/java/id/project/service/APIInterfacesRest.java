package id.project.service;


public interface APIInterfacesRest {

//    @GET("/")
//    Call<DataModel> getSearch(@Query("json") String json, @Query("search") String search);

}