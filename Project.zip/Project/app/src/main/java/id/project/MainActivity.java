package id.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import id.project.model.DataModel;
import id.project.utility.SharedPrefUtil;

public class MainActivity extends AppCompatActivity {
    EditText txtName, txtAddress, txtMom;
    CalendarView calendar;
    Button btnSearch;
    String tanggal="";
    private AppDatabase mDb;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtName     =findViewById(R.id.txtName);
        txtAddress  =findViewById(R.id.txtAddress);
        txtMom     =findViewById(R.id.txtMom);

        calendar    =findViewById(R.id.calendar);
        btnSearch   =findViewById(R.id.btnSearch);
//        mAuth = FirebaseAuth.getInstance();

        mDb = AppDatabase.getInstance(getApplicationContext());

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMMM-yyyy");
                Date date = new Date(year - 1900, month, dayOfMonth);
                tanggal = sdf.format(date);
                Toast.makeText(MainActivity.this, tanggal, Toast.LENGTH_LONG).show();
            }
        });

        String dataJson = SharedPrefUtil.getInstance(MainActivity.this).getString("data_input");

        if (!TextUtils.isEmpty(dataJson)) {

            // mappingData(dataJson);
        } else {

        }

        mDatabase = FirebaseDatabase.getInstance().getReference();
    }

    public void mappingData(String json) {
        DataModel dataModel = new Gson().fromJson(json, DataModel.class);
        txtName.setText(dataModel.getNama());
        txtAddress.setText(dataModel.getTempat_lahir());
        txtMom.setText(dataModel.getNama_ibu());

        Date dateDummy = null;
        try {
            dateDummy = new SimpleDateFormat("dd-MMMM-yyyy").parse(dataModel.getTanggal_lahir());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        calendar.setDate(dateDummy.getTime());
    }

    public List<DataModel> getModelArrayString(String json) {
        Gson gson = new Gson();
        Type type = new TypeToken<List<DataModel>>() {
        }.getType();
        List<DataModel> dataList = gson.fromJson(json, type);
        for (DataModel data : dataList) {
            Log.i("Contact Details", data.getNama() + "-" + data.getTempat_lahir() + "-" + data.getTanggal_lahir()+ "-" + data.getNama_ibu());
        }

        return dataList;
    }

    public boolean checkMandatory() {

        boolean pass = true;
        if (TextUtils.isEmpty(txtName.getText().toString())) {
            pass = false;
            txtName.setError("Masukan nama, mandatory");

        }


//        if (TextUtils.isEmpty(txtEmail.getText().toString()) || !Patterns.EMAIL_ADDRESS.matcher(txtEmail.getText().toString()).matches()) {
//            pass = false;
//            txtEmail.setError("Masukan email dengan format yang benar");
//        }

        return pass;
    }

    public void search(View view){
        if(checkMandatory()){

            new Thread(new Runnable() {
                @Override
                public void run() {

                    DataModel data1 = null;

                    data1 = (DataModel) mDb.dataModel1().findByNama(txtName.getText().toString());

                    if (data1 != null) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                showErrorDialog2();
                            }

                            private void showErrorDialog2() {
                                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                                alertDialog.setTitle("Peringatan");
                                alertDialog.setMessage("Mohon masukan telepon yang berbeda").setIcon(R.drawable.ic_close).setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                }).setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Toast.makeText(MainActivity.this, "Cancel ditekan", Toast.LENGTH_LONG).show();
                                    }
                                });

                                AlertDialog alert = alertDialog.create();
                                alert.show();
                            }

                        });
                    } else {
                        mDatabase.child("datanisn").child(generateObjectData().getNama()).setValue(generateObjectData());

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                showJsonDialog();
                            }

                            private void showJsonDialog() {
                                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
                                alertDialog.setTitle("Json");
                                alertDialog.setMessage("Sukses ").setIcon(R.drawable.ic_about).setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });

                                AlertDialog alert = alertDialog.create();
                                alert.show();
                            }

                        });
                    }
                }

            }).start();


        }else{
            showErrorDialog();
        }
    }



//    public List<DataModel> getListBiodata(String json) {
//
//
//        return null;
//    }


    public DataModel generateObjectData() {
        DataModel data1 = new DataModel();
        data1.setNama(txtName.getText().toString());
        data1.setTanggal_lahir(tanggal);
        data1.setTempat_lahir(txtAddress.getText().toString());
        data1.setNama_ibu(txtMom.getText().toString());

        return data1;
    }

    public void showErrorDialog() {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
        alertDialog.setTitle("Json");
        alertDialog.setMessage("Sukses ").setIcon(R.drawable.ic_about).setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alert = alertDialog.create();
        alert.show();
    }

//
}
