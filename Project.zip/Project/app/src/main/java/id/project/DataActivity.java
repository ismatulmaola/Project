package id.project;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class DataActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
    }
}
